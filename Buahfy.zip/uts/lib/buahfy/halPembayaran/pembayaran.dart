import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uts/buahfy/halPembayaran/pembayaran_provider.dart';
import 'package:uts/buahfy/widgets/navbar.dart'; 
import 'package:awesome_dialog/awesome_dialog.dart';

class PembayaranPage extends StatefulWidget {
  const PembayaranPage({Key? key}) : super(key: key);

  @override
  State<PembayaranPage> createState() => _PembayaranPageState();
}

class _PembayaranPageState extends State<PembayaranPage> {
  String _selectedPengiriman = 'Hemat';
  String _selectedMetode = 'Transfer Bank';
  bool _tukarKoin = false;

  final int hargaProduk = 38500;
  final int hargaPengiriman = 10000;
  final int koinDiskon = 500;

  List<String> pengirimanOptions = ['Hemat', 'Reguler', 'Express', 'Instant'];
  List<String> metodeOptions = ['Transfer Bank', 'E-Wallet', 'COD'];

  @override
  Widget build(BuildContext context) {
    final pembayaranProvider = Provider.of<PembayaranProvider>(context);
    int totalProduk = hargaProduk * pembayaranProvider.quantity;
    int totalBayar =
        totalProduk + hargaPengiriman - (_tukarKoin ? koinDiskon : 0);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Checkout', style: TextStyle(color: Colors.white)),
        leading: const BackButton(),
        backgroundColor: Colors.green,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildAlamat(),
            const SizedBox(height: 16),
            _buildProduk(context, pembayaranProvider),
            const SizedBox(height: 16),
            _buildPesanUntukPenjual(),
            _buildDropdownPengiriman(),
            _buildDropdownMetodePembayaran(),
            _buildTukarKoin(),
            const SizedBox(height: 10),
            _buildRincianPembayaran(totalProduk, totalBayar),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomButton(context, totalBayar),
    );
  }

  Widget _buildAlamat() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          const Icon(Icons.location_on, color: Colors.green),
          const SizedBox(width: 8),
          const Expanded(
            child: Text(
              'Merianti (+62) 877-7095-2031\nJl.Gede raya No.24 Medan Perjuangan\nMedan Perjuangan, Kota Medan, Sumut\nID 23245',
              style: TextStyle(fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProduk(BuildContext context, PembayaranProvider provider) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              image: const DecorationImage(
                image: AssetImage('assets/images/checkout.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Buah Anggur Merah 500 gr',
                  style: TextStyle(fontWeight: FontWeight.w500),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Rp38.500', style: TextStyle(color: Colors.red)),
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.remove_circle_outline),
                          onPressed: provider.decrement,
                        ),
                        Text(
                          '${provider.quantity}',
                          style: const TextStyle(fontSize: 16),
                        ),
                        IconButton(
                          icon: const Icon(Icons.add_circle_outline),
                          onPressed: provider.increment,
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPesanUntukPenjual() {
    return Padding(
      padding: const EdgeInsets.only(left: 16),
      child: Row(
        children: [
          const Text(
            'Pesan untuk Penjual',
            style: TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
          ),
          const SizedBox(width: 60),
          Expanded(
            child: TextField(
              style: const TextStyle(fontSize: 14),
              decoration: const InputDecoration(
                hintText: 'Tinggalkan pesan..',
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 5,
                  vertical: 4,
                ),
                border: InputBorder.none,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDropdownPengiriman() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            'Opsi Pengiriman',
            style: TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
          ),
          DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: _selectedPengiriman,
              items:
                  pengirimanOptions.map((item) {
                    return DropdownMenuItem(
                      value: item,
                      child: Text(item, style: const TextStyle(fontSize: 14)),
                    );
                  }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedPengiriman = value!;
                });
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDropdownMetodePembayaran() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            'Metode Pembayaran',
            style: TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
          ),
          DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: _selectedMetode,
              items:
                  metodeOptions.map((item) {
                    return DropdownMenuItem(
                      value: item,
                      child: Text(item, style: const TextStyle(fontSize: 14)),
                    );
                  }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedMetode = value!;
                });
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTukarKoin() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            'Tukarkan 500 koin',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          Checkbox(
            value: _tukarKoin,
            activeColor: Colors.green,
            onChanged: (value) {
              setState(() {
                _tukarKoin = value!;
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _buildRincianPembayaran(int totalProduk, int totalBayar) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.grey[200]),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Rincian Pembayaran',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          _buildRow('Subtotal untuk Produk', 'Rp$totalProduk'),
          _buildRow('Subtotal untuk Pengiriman', 'Rp$hargaPengiriman'),
          _buildRow('Gunakan coin', _tukarKoin ? '-Rp$koinDiskon' : 'Rp0'),
          _buildRow('Total Pembayaran', 'Rp$totalBayar', isBold: true),
        ],
      ),
    );
  }

  Widget _buildBottomButton(BuildContext context, int totalBayar) {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Expanded(
            child: Text(
              'Total Rp$totalBayar',
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
                color: Colors.red,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              AwesomeDialog(
                context: context,
                dialogType: DialogType.success,
                animType: AnimType.scale,
                title: 'Pembayaran Berhasil',
                desc: 'Pesanan Anda telah berhasil dibuat!',
                btnOkOnPress: () {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                      builder: (context) => MainPage(initialIndex: 0), // ✅
                    ),
                    (route) => false,
                  );
                },
                btnOkText: 'OK',
                btnOkColor: Colors.green,
              ).show();
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            child: const Text(
              'Buat Pesanan',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRow(String label, String value, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }
}
