import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:chip_list/chip_list.dart';
import 'package:uts/buahfy/halPembayaran/pembayaran.dart';
import 'keranjang_provider.dart';

class KeranjangPage extends StatelessWidget {
  const KeranjangPage({super.key});

  @override
  Widget build(BuildContext context) {
    final keranjang = Provider.of<KeranjangProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          '      Keranjang Saya',
          style: TextStyle(color: Colors.white),
        ),
        leading: const BackButton(),
        backgroundColor: Colors.green,
      ),
      body: Column(
        children: [
          const SizedBox(height: 8),
          Expanded(
            child: ListView.builder(
              itemCount: keranjang.items.length,
              itemBuilder: (context, index) {
                final item = keranjang.items[index];

                return Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 6,
                  ),
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 6,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Transform.translate(
                        offset: const Offset(-15, 0),
                        child: Checkbox(
                          value: item.isSelected,
                          onChanged: (_) => keranjang.toggleSelection(index),
                        ),
                      ),
                      Transform.translate(
                        offset: const Offset(-15, 0),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.asset(
                            item.image,
                            width: 90,
                            height: 90,
                            fit: BoxFit.contain,
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              item.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4),
                            GestureDetector(
                              onTap: () async {
                                int selectedFruitIndex = 0;
                                int selectedWeightIndex = 0;
                                int selectedCategoryIndex = 0;

                                final fruits = [
                                  'Anggur Hijau',
                                  'Anggur Merah',
                                  'Anggur Hitam',
                                ];
                                final weights = ['500 Gr', '1 Kg'];
                                final categories = ['Lokal', 'Impor'];

                                await showModalBottomSheet(
                                  context: context,
                                  isScrollControlled: true,
                                  shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.vertical(
                                      top: Radius.circular(20),
                                    ),
                                  ),
                                  builder: (_) {
                                    return StatefulBuilder(
                                      builder: (context, setState) {
                                        return Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                            16,
                                            24,
                                            16,
                                            30,
                                          ),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Row(
                                                children: [
                                                  ClipRRect(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          12,
                                                        ),
                                                    child: Image.asset(
                                                      item.image,
                                                      height: 70,
                                                    ),
                                                  ),
                                                  const SizedBox(width: 12),
                                                  Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Text(
                                                        'Rp${item.price.toStringAsFixed(0)}',
                                                        style: const TextStyle(
                                                          color: Colors.red,
                                                          fontSize: 18,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                                      ),
                                                      Text(
                                                        'Stok : 100',
                                                        style: TextStyle(
                                                          color:
                                                              Colors.grey[600],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                              const SizedBox(height: 24),

                                              // Varian
                                              const Text(
                                                'Varian',
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              const SizedBox(height: 8),
                                              ChipList(
                                                listOfChipNames: fruits,
                                                listOfChipIndicesCurrentlySelected:
                                                    [selectedFruitIndex],
                                                supportsMultiSelect: false,
                                                activeBgColorList: [
                                                  Colors.green[100]!,
                                                ],
                                                inactiveBgColorList: [
                                                  Colors.grey[200]!,
                                                ],
                                                activeTextColorList: [
                                                  Colors.black,
                                                ],
                                                inactiveTextColorList: [
                                                  Colors.black,
                                                ],
                                                shouldWrap: true,
                                                extraOnToggle: (val) {
                                                  setState(() {
                                                    selectedFruitIndex = val;
                                                  });
                                                },
                                              ),
                                              const Divider(height: 32),

                                              // Berat
                                              const Text(
                                                'Berat',
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              const SizedBox(height: 8),
                                              ChipList(
                                                listOfChipNames: weights,
                                                listOfChipIndicesCurrentlySelected:
                                                    [selectedWeightIndex],
                                                supportsMultiSelect: false,
                                                activeBgColorList: [
                                                  Colors.green[100]!,
                                                ],
                                                inactiveBgColorList: [
                                                  Colors.grey[200]!,
                                                ],
                                                activeTextColorList: [
                                                  Colors.black,
                                                ],
                                                inactiveTextColorList: [
                                                  Colors.black,
                                                ],
                                                shouldWrap: true,
                                                extraOnToggle: (val) {
                                                  setState(() {
                                                    selectedWeightIndex = val;
                                                  });
                                                },
                                              ),
                                              const Divider(height: 32),

                                              // Kategori
                                              const Text(
                                                'Kategori',
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              const SizedBox(height: 8),
                                              ChipList(
                                                listOfChipNames: categories,
                                                listOfChipIndicesCurrentlySelected:
                                                    [selectedCategoryIndex],
                                                supportsMultiSelect: false,
                                                activeBgColorList: [
                                                  Colors.green[100]!,
                                                ],
                                                inactiveBgColorList: [
                                                  Colors.grey[200]!,
                                                ],
                                                activeTextColorList: [
                                                  Colors.black,
                                                ],
                                                inactiveTextColorList: [
                                                  Colors.black,
                                                ],
                                                shouldWrap: true,
                                                extraOnToggle: (val) {
                                                  setState(() {
                                                    selectedCategoryIndex = val;
                                                  });
                                                },
                                              ),

                                              const SizedBox(height: 20),
                                              SizedBox(
                                                width: double.infinity,
                                                height: 48,
                                                child: ElevatedButton(
                                                  onPressed: () {
                                                    keranjang.updateVariant(
                                                      index,
                                                      fruitVariant:
                                                          fruits[selectedFruitIndex],
                                                      weight:
                                                          weights[selectedWeightIndex],
                                                      category:
                                                          categories[selectedCategoryIndex],
                                                    );
                                                    Navigator.pop(context);
                                                  },
                                                  style: ElevatedButton.styleFrom(
                                                    backgroundColor:
                                                        Colors.green,
                                                    shape: RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                            10,
                                                          ),
                                                    ),
                                                  ),
                                                  child: const Text(
                                                    'Simpan Pilihan',
                                                    style: TextStyle(
                                                      color: Colors.white,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        );
                                      },
                                    );
                                  },
                                );
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 6,
                                  vertical: 2,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.green.shade50,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: Text(
                                  item.combinedVariant,
                                  style: const TextStyle(
                                    fontSize: 12,
                                    color: Colors.green,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 6),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Rp${item.price.toStringAsFixed(0)}',
                                  style: const TextStyle(
                                    color: Colors.red,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Row(
                                  children: [
                                    IconButton(
                                      onPressed:
                                          () => keranjang.decrementQuantity(
                                            index,
                                          ),
                                      icon: const Icon(
                                        Icons.remove_circle_outline,
                                      ),
                                    ),
                                    Text(item.quantity.toString()),
                                    IconButton(
                                      onPressed:
                                          () => keranjang.incrementQuantity(
                                            index,
                                          ),
                                      icon: const Icon(
                                        Icons.add_circle_outline,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),

          // Footer Total & Checkout
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            height: 70,
            decoration: const BoxDecoration(
              color: Colors.white,
              boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 4)],
            ),
            child: Row(
              children: [
                Checkbox(
                  value: keranjang.isAllSelected,
                  onChanged: (value) => keranjang.selectAll(value ?? false),
                ),
                const Text('Semua'),
                const Spacer(),
                Text(
                  'Total Rp${keranjang.totalPrice.toStringAsFixed(0)}',
                  style: const TextStyle(
                    color: Colors.red,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(width: 10),
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => PembayaranPage()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: const Text('Checkout'),
                ),
              ],
            ),
          ),
        ],
      ),
      backgroundColor: const Color(0xFFF5F5F5),
    );
  }
}
