import 'package:flutter/material.dart';

class CartItem {
  final String name;
  String fruitVariant;
  String weight;
  String category;
  final String image;
  final double price;
  int quantity;
  bool isSelected;

  CartItem({
    required this.name,
    required this.fruitVariant,
    required this.weight,
    required this.category,
    required this.image,
    required this.price,
    this.quantity = 1,
    this.isSelected = false,
  });

  String get combinedVariant => '$fruitVariant, $weight, $category';
}

class KeranjangProvider with ChangeNotifier {
  final List<CartItem> _items = [
    CartItem(
      name: 'Buah Anggur Premium Berkualitas – Manis & Segar',
      fruitVariant: 'Anggur Merah',
      weight: '500 gr',
      category: 'Lokal',
      image: 'assets/images/checkout.jpg',
      price: 38500,
    ),
    CartItem(
      name: 'Buah Kiwi Segar Pilihan – Kaya Vitamin C',
      fruitVariant: 'Kiwi Hijau',
      weight: '1 kg',
      category: 'Lokal',
      image: 'assets/images/kiw.jpg',
      price: 48000,
    ),
    CartItem(
      name: 'Apel Fuji Impor Istimewa – Renyah & Manis',
      fruitVariant: 'Apel Hijau',
      weight: '1 kg',
      category: 'Impor',
      image: 'assets/images/apel.jpg',
      price: 28500,
    ),
  ];

  List<CartItem> get items => _items;

  void addItem(CartItem item) {
    _items.add(item);
    notifyListeners();
  }

  int get totalItems => _items.length;

  void toggleSelection(int index) {
    _items[index].isSelected = !_items[index].isSelected;
    notifyListeners();
  }

  void updateVariant(
    int index, {
    required String fruitVariant,
    required String weight,
    required String category,
  }) {
    _items[index].fruitVariant = fruitVariant;
    _items[index].weight = weight;
    _items[index].category = category;
    notifyListeners();
  }

  void selectAll(bool value) {
    for (var item in _items) {
      item.isSelected = value;
    }
    notifyListeners();
  }

  bool get isAllSelected => _items.every((item) => item.isSelected);

  double get totalPrice => _items
      .where((item) => item.isSelected)
      .fold(0.0, (sum, item) => sum + (item.price * item.quantity));

  void incrementQuantity(int index) {
    _items[index].quantity++;
    notifyListeners();
  }

  void decrementQuantity(int index) {
    if (_items[index].quantity > 1) {
      _items[index].quantity--;
      notifyListeners();
    }
  }
}
