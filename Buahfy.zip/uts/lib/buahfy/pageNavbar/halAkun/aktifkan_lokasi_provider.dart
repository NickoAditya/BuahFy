import 'package:flutter/material.dart';

class AktifkanLokasiProvider with ChangeNotifier {
  bool _isLocationActive = false;

  bool get isLocationActive => _isLocationActive;

  void toggleLocation(bool value) {
    _isLocationActive = value;
    notifyListeners();
  }
}
