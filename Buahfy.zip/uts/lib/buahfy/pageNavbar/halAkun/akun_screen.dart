import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uts/buahfy/login.dart';
import 'package:uts/buahfy/pageNavbar/halAkun/aktifkan_lokasi_provider.dart';
import 'package:uts/buahfy/widgets/navbar.dart';

class AkunScreen extends StatefulWidget {
  @override
  State<AkunScreen> createState() => _AkunScreenState();
}

class _AkunScreenState extends State<AkunScreen> {
  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    final lokasiProvider = Provider.of<AktifkanLokasiProvider>(context);

    return Stack(
      children: [
        Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            backgroundColor: const Color.fromARGB(255, 85, 231, 119),
            elevation: 1,
            leading: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.brown),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => MainPage()),
                );
              },
            ),
            title: const Text('Akun', style: TextStyle(color: Colors.black)),
            centerTitle: true,
            actions: [
              TextButton(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder:
                        (context) => AlertDialog(
                          title: Text('Konfirmasi Perubahan'),
                          content: Text(
                            'Apakah Anda yakin menyimpan perubahan pada akun?',
                          ),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context),
                              child: Text(
                                'Batal',
                                style: TextStyle(color: Colors.red),
                              ),
                            ),
                            ElevatedButton(
                              onPressed: () {
                                Navigator.pop(context);
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (_) => MainPage()),
                                );
                              },
                              child: Text(
                                'Simpan',
                                style: TextStyle(
                                  color: const Color.fromARGB(255, 54, 181, 40),
                                ),
                              ),
                            ),
                          ],
                        ),
                  );
                },
                child: const Text(
                  'Simpan',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
          body: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 30,
                      backgroundColor: Colors.green,
                      child: Icon(Icons.person, size: 40, color: Colors.white),
                    ),
                    const SizedBox(width: 16),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Budi Susanto',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            color: Colors.black,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: const [
                            Icon(
                              Icons.monetization_on,
                              size: 16,
                              color: Colors.amber,
                            ),
                            SizedBox(width: 4),
                            Text(
                              '500',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.black,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: const [
                            Icon(
                              Icons.account_balance_wallet_outlined,
                              size: 16,
                              color: Colors.grey,
                            ),
                            SizedBox(width: 4),
                            Text(
                              'Saldo Rp0',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.black,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Divider(thickness: 8, color: Color(0xFFF5F5F5)),
              Expanded(
                child: ListView(
                  children: [
                    _buildListTile(Icons.home_outlined, 'Alamat Saya', () {}),
                    _buildListTile(
                      Icons.receipt_long_outlined,
                      'Daftar Transaksi',
                      () {},
                    ),
                    _buildListTile(Icons.star_border, 'Ulasan', () {}),
                    _buildListTile(Icons.favorite_border, 'Wishlist', () {}),
                    ListTile(
                      leading: Icon(
                        Icons.location_on_outlined,
                        color: Colors.black,
                      ),
                      title: Text(
                        'Aktifkan lokasi',
                        style: TextStyle(color: Colors.black),
                      ),
                      trailing: Transform.scale(
                        scale: 0.8,
                        child: Switch(
                          value: lokasiProvider.isLocationActive,
                          activeColor: Colors.green,
                          onChanged: (value) async {
                            setState(() => _isLoading = true);
                            await Future.delayed(
                              Duration(seconds: 1),
                            ); // Simulasi proses async
                            lokasiProvider.toggleLocation(value);
                            setState(() => _isLoading = false);
                          },
                        ),
                      ),
                    ),
                    Divider(thickness: 8, color: Color(0xFFF5F5F5)),
                    _buildListTile(
                      Icons.headphones,
                      'Pusat Bantuan Buahfy',
                      () {},
                    ),
                    _buildListTile(Icons.logout, 'Log Out', () async {
                      bool confirm = await showDialog(
                        context: context,
                        builder:
                            (context) => AlertDialog(
                              title: Text('Konfirmasi'),
                              content: Text('Apakah Anda yakin ingin keluar?'),
                              actions: [
                                TextButton(
                                  onPressed:
                                      () => Navigator.pop(context, false),
                                  child: Text(
                                    'Batal',
                                    style: TextStyle(color: Colors.white),
                                  ),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.green,
                                  ),
                                ),
                                TextButton(
                                  onPressed: () => Navigator.pop(context, true),
                                  child: Text(
                                    'Ya',
                                    style: TextStyle(color: Colors.red),
                                  ),
                                ),
                              ],
                            ),
                      );
                      if (confirm) {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => LoginBuahApp(),
                          ),
                        );
                      }
                    }),
                  ],
                ),
              ),
            ],
          ),
        ),
        if (_isLoading)
          Container(
            color: Colors.black.withOpacity(0.3),
            child: const Center(child: CircularProgressIndicator()),
          ),
      ],
    );
  }

  Widget _buildListTile(IconData icon, String title, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon, color: Colors.black),
      title: Text(title, style: TextStyle(color: Colors.black)),
      onTap: onTap,
    );
  }
}
