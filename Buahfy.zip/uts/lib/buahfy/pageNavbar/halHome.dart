import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:badges/badges.dart' as badges;
import 'package:uts/buahfy/produk.dart';
import 'package:uts/buahfy/keranjangg/keranjang.dart';
import 'package:uts/buahfy/keranjangg/keranjang_provider.dart';

class FruitShopHomePage extends StatefulWidget {
  @override
  _FruitShopHomePageState createState() => _FruitShopHomePageState();
}

class _FruitShopHomePageState extends State<FruitShopHomePage> {
  String _selectedFilter = 'Semua';
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();

  final List<Map<String, String>> fruits = [
    {
      'name': 'Buah Anggur Premium Berkualitas – Manis & Segar',
      'price': 'Rp38.500',
      'image': 'assets/images/checkout.jpg',
    },
    {
      'name': 'Buah Kiwi Segar Pilihan – Kaya Vitamin C',
      'price': 'Rp48.000',
      'image': 'assets/images/kiw.jpg',
    },
    {
      'name': 'Apel Fuji Impor Istimewa – Renyah & Manis',
      'price': 'Rp28.500',
      'image': 'assets/images/apel.jpg',
    },
    {
      'name': 'Jeruk Manis Berkualitas Super – Penuh Nutrisi',
      'price': 'Rp26.500',
      'image': 'assets/images/jeruk.jpg',
    },
    {
      'name': 'Strawberry Fresh Grade A – Asam Manis Alami',
      'price': 'Rp31.500',
      'image': 'assets/images/strawberry.png',
    },
    {
      'name': 'Manggis Tropis Unggulan – Rasa Manis yang Sempurna',
      'price': 'Rp39.500',
      'image': 'assets/images/manggis.jpg',
    },
  ];

  List<Map<String, String>> get filteredFruits {
    List<Map<String, String>> list;

    if (_selectedFilter == 'Semua') {
      list = fruits;
    } else if (_selectedFilter == 'Terbaru') {
      list = fruits.reversed.toList();
    } else if (_selectedFilter == 'Terlaris') {
      final bestSellers = ['jeruk', 'apel', 'strawberry', 'anggur'];
      list =
          fruits.where((fruit) {
            final name = fruit['name']?.toLowerCase() ?? '';
            return bestSellers.any((keyword) => name.contains(keyword));
          }).toList();
    } else {
      list = fruits;
    }

    // Filter by search query
    if (_searchQuery.isNotEmpty) {
      list =
          list.where((fruit) {
            final name = fruit['name']?.toLowerCase() ?? '';
            return name.contains(_searchQuery.toLowerCase());
          }).toList();
    }

    return list;
  }

  void _onFilterSelected(String filter) {
    setState(() {
      _selectedFilter = filter;
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.green,
        elevation: 0,
        toolbarHeight: 60,
        automaticallyImplyLeading: false,
        flexibleSpace: Padding(
          padding: const EdgeInsets.fromLTRB(16, 40, 16, 10),
          child: Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 40,
                  child: TextField(
                    controller: _searchController,
                    onChanged: (value) {
                      setState(() {
                        _searchQuery = value;
                      });
                    },
                    decoration: InputDecoration(
                      hintText: 'Cari buah yang ingin anda beli',
                      prefixIcon: Icon(Icons.search),
                      filled: true,
                      fillColor: Colors.green[100],
                      contentPadding: EdgeInsets.symmetric(
                        vertical: 8,
                        horizontal: 20,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(width: 10),
              Consumer<KeranjangProvider>(
                builder: (context, keranjangProvider, _) {
                  return badges.Badge(
                    position: badges.BadgePosition.topEnd(top: -6, end: -4),
                    showBadge: keranjangProvider.items.isNotEmpty,
                    badgeContent: Text(
                      '${keranjangProvider.items.length}',
                      style: TextStyle(color: Colors.white, fontSize: 10),
                    ),
                    badgeStyle: badges.BadgeStyle(
                      badgeColor: Colors.red,
                      padding: EdgeInsets.all(5),
                    ),
                    child: IconButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => KeranjangPage(),
                          ),
                        );
                      },
                      icon: Container(
                        padding: EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.shopping_cart,
                          color: Color.fromARGB(255, 29, 131, 11),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16.0,
                  vertical: 10,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Buah Populer',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        children: [
                          buildPromoImage('assets/images/kiwi.jpg'),
                          SizedBox(height: 10),
                          buildPromoImage('assets/images/apple.jpg'),
                        ],
                      ),
                    ),
                    SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        children: [
                          buildPromoImage('assets/images/orange.jpg'),
                          SizedBox(height: 10),
                          buildPromoImage('assets/images/alpukat.jpg'),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),
              Wrap(
                spacing: 10,
                alignment: WrapAlignment.center,
                children:
                    ['Semua', 'Terbaru', 'Terlaris'].map((filter) {
                      return FilterChip(
                        label: Text(filter),
                        padding: EdgeInsets.symmetric(
                          horizontal: 15,
                          vertical: 10,
                        ),
                        selected: _selectedFilter == filter,
                        onSelected: (_) => _onFilterSelected(filter),
                        selectedColor: Colors.green,
                        checkmarkColor: Colors.white,
                        labelStyle: TextStyle(
                          color:
                              _selectedFilter == filter
                                  ? Colors.white
                                  : Colors.black,
                        ),
                        backgroundColor: Colors.green[50],
                        shape: StadiumBorder(
                          side: BorderSide(color: Colors.green),
                        ),
                      );
                    }).toList(),
              ),
              SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: GridView.count(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 0.8,
                  children:
                      filteredFruits.map((fruit) {
                        return GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => ProductPage()),
                            );
                          },
                          child: ProductCard(
                            name: fruit['name']!,
                            price: fruit['price']!,
                            imageUrl: fruit['image']!,
                          ),
                        );
                      }).toList(),
                ),
              ),
              SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildPromoImage(String assetPath) {
    return Container(
      width: 300,
      height: 85,
      decoration: BoxDecoration(
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            spreadRadius: 2,
            blurRadius: 5,
            offset: Offset(0, 2),
          ),
        ],
        borderRadius: BorderRadius.circular(11),
        image: DecorationImage(image: AssetImage(assetPath), fit: BoxFit.cover),
      ),
    );
  }
}

class ProductCard extends StatelessWidget {
  final String name;
  final String price;
  final String imageUrl;

  const ProductCard({
    required this.name,
    required this.price,
    required this.imageUrl,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 1,
      color: Colors.green[100],
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: Colors.green, width: 2),
      ),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.asset(
                imageUrl,
                width: double.infinity,
                height: 100,
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(height: 8),
            Text(
              name,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 12,
                color: Colors.black,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.start,
            ),
            SizedBox(height: 8),
            Text(
              price,
              style: TextStyle(
                color: Colors.red[700],
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.start,
            ),
          ],
        ),
      ),
    );
  }
}
