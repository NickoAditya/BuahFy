import 'package:flutter/material.dart';
import 'package:uts/buahfy/widgets/sheetbuttom.dart';
import 'package:uts/buahfy/widgets/sheetbuttom2.dart';
import 'package:uts/buahfy/pageNavbar/chat.dart';

class ProductPage extends StatelessWidget {
  const ProductPage({super.key});

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Stack(
                children: [
                  Image.asset(
                    'assets/images/checkout.jpg',
                    width: screenWidth * 0.99,
                    height: 400,
                    fit: BoxFit.contain,
                  ),
                  Positioned(
                    top: 16,
                    left: 16,
                    child: GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: const CircleAvatar(
                        backgroundColor: Colors.white,
                        child: Icon(Icons.arrow_back, color: Colors.black),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 16,
                    right: 16,
                    child: PopupMenuButton<String>(
                      icon: const Icon(Icons.more_vert, color: Colors.black),
                      onSelected: (value) {
                        if (value == 'Bagikan') {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text(
                                'Link berhasil dicopy',
                                style: TextStyle(
                                  color: Color.fromARGB(255, 4, 41, 5),
                                ),
                              ),
                              backgroundColor: Color.fromARGB(
                                255,
                                234,
                                234,
                                234,
                              ),
                            ),
                          );
                        } else if (value == 'Laporkan produk ini') {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text(
                                'Produk berhasil dilaporkan !!',
                                style: TextStyle(color: Colors.red),
                              ),
                              backgroundColor: Color.fromARGB(
                                255,
                                234,
                                234,
                                234,
                              ),
                            ),
                          );
                        }
                      },
                      itemBuilder:
                          (BuildContext context) => [
                            const PopupMenuItem(
                              value: 'Bagikan',
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.share,
                                    color: Color.fromARGB(255, 90, 90, 90),
                                  ),
                                  SizedBox(width: 6),
                                  Text('Bagikan'),
                                ],
                              ),
                            ),
                            const PopupMenuItem(
                              value: 'Laporkan produk ini',
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.report_problem_rounded,
                                    color: Color.fromARGB(255, 90, 90, 90),
                                  ),
                                  SizedBox(width: 6),
                                  Text('Laporkan produk ini'),
                                ],
                              ),
                            ),
                          ],
                    ),
                  ),
                ],
              ),
              const Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Rp38.500',
                      style: TextStyle(
                        color: Colors.red,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'Buah Anggur Premium Berkualitas – Manis & Segar',
                      style: TextStyle(fontSize: 18),
                    ),
                    SizedBox(height: 15),
                    Divider(),
                    SizedBox(height: 5),
                    Row(
                      children: [
                        Icon(Icons.star, color: Colors.amber, size: 30),
                        Icon(Icons.star, color: Colors.amber, size: 30),
                        Icon(Icons.star, color: Colors.amber, size: 30),
                        Icon(Icons.star, color: Colors.amber, size: 30),
                        Icon(Icons.star_half, color: Colors.amber, size: 30),
                        SizedBox(width: 8),
                        Text('4,7', style: TextStyle(fontSize: 16)),
                      ],
                    ),
                    SizedBox(height: 5),
                    Divider(),
                    Text(
                      'Deskripsi',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Anggur merah segar pilihan dengan rasa manis alami dan tekstur renyah. '
                      'Cocok dinikmati langsung sebagai camilan sehat, dicampur dalam salad, '
                      'atau dijadikan jus yang menyegarkan. Kaya akan antioksidan, vitamin C, '
                      'dan serat yang baik untuk kesehatan.',
                      style: TextStyle(fontSize: 16, height: 1.5),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 6,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        height: 60,
        child: Row(
          children: [
            // Chat Icon – sudah diperbaiki
            Expanded(
              flex: 1,
              child: IconButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const ChattingPage(),
                    ),
                  );
                },
                icon: const Icon(
                  Icons.chat,
                  color: Color.fromARGB(255, 29, 131, 11),
                ),
              ),
            ),
            Container(width: 1, height: 35, color: Colors.grey.shade300),

            // Cart Icon
            Expanded(
              flex: 1,
              child: IconButton(
                onPressed: () {
                  showModalBottomSheet(
                    context: context,
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.vertical(
                        top: Radius.circular(20),
                      ),
                    ),
                    isScrollControlled: true,
                    builder: (context) {
                      return CartOptionsSheet2();
                    },
                  );
                },
                icon: const Icon(
                  Icons.shopping_cart,
                  color: Color.fromARGB(255, 29, 131, 11),
                ),
              ),
            ),
            Container(width: 1, height: 40, color: Colors.grey.shade300),

            // Beli Sekarang
            Expanded(
              flex: 3,
              child: SizedBox(
                height: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 23, 182, 28),
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero,
                    ),
                    elevation: 0,
                  ),
                  onPressed: () {
                    showModalBottomSheet(
                      context: context,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.vertical(
                          top: Radius.circular(20),
                        ),
                      ),
                      isScrollControlled: true,
                      builder: (context) {
                        return CartOptionsSheet();
                      },
                    );
                  },
                  child: const Text(
                    'Beli Sekarang',
                    style: TextStyle(color: Colors.white, fontSize: 16),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
