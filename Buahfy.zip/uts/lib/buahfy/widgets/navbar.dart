import 'package:flutter/material.dart';
import 'package:convex_bottom_bar/convex_bottom_bar.dart';
import 'package:uts/buahfy/pageNavbar/chat.dart';
import 'package:uts/buahfy/pageNavbar/halAkun/akun_screen.dart';
import 'package:uts/buahfy/pageNavbar/halHome.dart';

class MainPage extends StatefulWidget {
  final int initialIndex;

  const MainPage({super.key, this.initialIndex = 0});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  late int _selectedIndex;

  final List<Widget> _pages = [
    FruitShopHomePage(),
    ChattingPage(),
    AkunScreen(),
  ];

  @override
  void initState() {
    super.initState();
    _selectedIndex = widget.initialIndex;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex],
      bottomNavigationBar: ConvexAppBar(
        backgroundColor: Colors.green,
        activeColor: Colors.white,
        color: Colors.white,
        style: TabStyle.react,
        items: [
          TabItem(
            icon: Icons.home,
            title: _selectedIndex == 0 ? 'Beranda' : '',
          ),
          TabItem(
            icon: Icons.chat,
            title: _selectedIndex == 1 ? 'Chat' : '',
          ),
          TabItem(
            icon: Icons.person,
            title: _selectedIndex == 2 ? 'Akun' : '',
          ),
        ],
        initialActiveIndex: _selectedIndex,
        onTap: (int index) {
          setState(() {
            _selectedIndex = index;
          });
        },
      ),
    );
  }
}
