import 'package:flutter/material.dart';
import 'package:uts/buahfy/halPembayaran/pembayaran.dart';

class CartOptionsSheet extends StatefulWidget {
  @override
  State<CartOptionsSheet> createState() => _CartOptionsSheetState();
}

class _CartOptionsSheetState extends State<CartOptionsSheet> {
  String selectedVariant = 'Anggur Merah';
  String selectedWeight = '500 Gram';
  String selectedCategory = 'Lokal';
  int quantity = 1;

  Widget _buildChoiceChipGroup(
    String label,
    List<String> options,
    String selected,
    Function(String) onSelected,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 10,
          children:
              options.map((option) {
                return ChoiceChip(
                  label: Text(option),
                  selected: selected == option,
                  onSelected: (_) => onSelected(option),
                  selectedColor: Colors.green[100],
                  backgroundColor: Colors.grey[200],
                  labelStyle: TextStyle(color: Colors.black),
                );
              }).toList(),
        ),
        const SizedBox(height: 16),
        Divider(thickness: 1),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: 16, left: 16, right: 16, bottom: 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Header
          Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.asset('assets/images/checkout.jpg', height: 70),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Rp38.500',
                    style: TextStyle(
                      color: Colors.red,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text('Stok : 100', style: TextStyle(color: Colors.grey[600])),
                ],
              ),
            ],
          ),

          const SizedBox(height: 24),

          // Varian
          _buildChoiceChipGroup(
            'Varian',
            ['Anggur Hijau', 'Anggur Merah', 'Anggur Hitam'],
            selectedVariant,
            (val) => setState(() => selectedVariant = val),
          ),

          // Berat
          _buildChoiceChipGroup(
            'Berat',
            ['500 Gram', '1 KiloGram'],
            selectedWeight,
            (val) => setState(() => selectedWeight = val),
          ),

          // Kategori
          _buildChoiceChipGroup(
            'Kategori',
            ['Lokal', 'Impor'],
            selectedCategory,
            (val) => setState(() => selectedCategory = val),
          ),

          // Jumlah
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Jumlah', style: TextStyle(fontWeight: FontWeight.bold)),
              Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.remove_circle_outline),
                    onPressed: () {
                      if (quantity > 1) setState(() => quantity--);
                    },
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    child: Text(
                      quantity.toString(),
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.add_circle_outline),
                    onPressed: () => setState(() => quantity++),
                  ),
                ],
              ),
            ],
          ),

          const SizedBox(height: 16),

          // Tombol Beli Sekarang
          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.greenAccent[400],
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              onPressed: () {
                Navigator.pop(context); // Tutup BottomSheet
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PembayaranPage()),
                );
              },
              child: Text(
                'Beli Sekarang',
                style: TextStyle(color: Colors.white, fontSize: 16),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
