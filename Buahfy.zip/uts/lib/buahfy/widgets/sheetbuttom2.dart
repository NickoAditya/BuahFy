import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uts/buahfy/keranjangg/keranjang_provider.dart';

class CartOptionsSheet2 extends StatefulWidget {
  @override
  State<CartOptionsSheet2> createState() => _CartOptionsSheetState();
}

class _CartOptionsSheetState extends State<CartOptionsSheet2> {
  String selectedVariant = 'Anggur Merah';
  String selectedWeight = '500 Gram';
  String selectedCategory = 'Lokal';
  int quantity = 1;

  Widget _buildChoiceChipGroup(
    String label,
    List<String> options,
    String selected,
    Function(String) onSelected,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 10,
          children:
              options.map((option) {
                return ChoiceChip(
                  label: Text(option),
                  selected: selected == option,
                  onSelected: (_) => onSelected(option),
                  selectedColor: Colors.green[100],
                  backgroundColor: Colors.grey[200],
                  labelStyle: TextStyle(color: Colors.black),
                );
              }).toList(),
        ),
        const SizedBox(height: 16),
        Divider(thickness: 1),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: 16, left: 16, right: 16, bottom: 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Header
          Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.asset('assets/images/checkout.jpg', height: 70),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Rp38.500',
                    style: TextStyle(
                      color: Colors.red,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text('Stok : 100', style: TextStyle(color: Colors.grey[600])),
                ],
              ),
            ],
          ),

          const SizedBox(height: 24),

          _buildChoiceChipGroup(
            'Varian',
            ['Anggur Hijau', 'Anggur Merah', 'Anggur Hitam'],
            selectedVariant,
            (val) => setState(() => selectedVariant = val),
          ),

          _buildChoiceChipGroup(
            'Berat',
            ['500 Gram', '1 KiloGram'],
            selectedWeight,
            (val) => setState(() => selectedWeight = val),
          ),

          _buildChoiceChipGroup(
            'Kategori',
            ['Lokal', 'Impor'],
            selectedCategory,
            (val) => setState(() => selectedCategory = val),
          ),

          // Jumlah
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Jumlah', style: TextStyle(fontWeight: FontWeight.bold)),
              Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.remove_circle_outline),
                    onPressed: () {
                      if (quantity > 1) setState(() => quantity--);
                    },
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    child: Text(
                      quantity.toString(),
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.add_circle_outline),
                    onPressed: () => setState(() => quantity++),
                  ),
                ],
              ),
            ],
          ),

          const SizedBox(height: 16),

          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.greenAccent[400],
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              onPressed: () {
                final keranjang = Provider.of<KeranjangProvider>(
                  context,
                  listen: false,
                );

                keranjang.addItem(
                  CartItem(
                    name: 'Buah Anggur Premium Berkualitas – Manis & Segar',
                    fruitVariant: selectedVariant,
                    weight: selectedWeight,
                    category: selectedCategory,
                    image: 'assets/images/checkout.jpg',
                    price: 38500,
                    quantity: quantity,
                  ),
                );

                Navigator.pop(context);

                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Produk berhasil dimasukkan ke keranjang!'),
                    backgroundColor: Colors.green,
                  ),
                );
              },
              child: Text(
                'Masukkan Keranjang',
                style: TextStyle(color: Colors.white, fontSize: 16),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
