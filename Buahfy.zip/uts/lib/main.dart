import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uts/buahfy/halPembayaran/pembayaran_provider.dart';
import 'package:uts/buahfy/halPertama.dart';
import 'package:uts/buahfy/keranjangg/keranjang_provider.dart';
import 'buahfy/pageNavbar/halAkun/aktifkan_lokasi_provider.dart'
    show AktifkanLokasiProvider;

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => PembayaranProvider()),
        ChangeNotifierProvider(create: (_) => AktifkanLokasiProvider()),
        ChangeNotifierProvider(create: (_) => KeranjangProvider()),
      ],
      child: BuahfyApp(),
    ),
  );
}

class BuahfyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: WelcomeScreen(),
    );
  }
}
